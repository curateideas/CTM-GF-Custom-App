﻿
# Container name and Version
$containerName = 'createbcdb'
$artifactUrl = Get-BcArtifactUrl -type 'OnPrem' -version '18.3' -country 'de' -select 'Latest'

$password = 'P@ssw0rd'
$securePassword = ConvertTo-SecureString -String $password -AsPlainText -Force
$credential = New-Object pscredential 'admin', $securePassword
$auth = 'UserPassword'
$licenseFile = '\\ctm-computer.int\dyn\Dyn_Lizenzen\BC_current\BC_Prog_CTM_4805307.flf'


# Path names for app files must be declared as URL accessable for every developer
$appFileApp1 = "D:\BC_Apps\gbedv\OPplus\D365_BC18_DE_UR03_OPP1800_Extension\OPplus Release - BC 18 CU 03\Runtime_Package\gbedv GmbH & Co. KG_OPplus 365_18.1801.20210708.3.runtime.app"
$appFileApp2 = "D:\BC_Apps\Sievers\DATEV\SIEVERS-GROUP_SNC DATEV_18.3.1.30.app"

New-BcContainer `
    -accept_eula `
    -containerName $containerName `
    -additionalparamaters @("--volume C:\Temp:c:\Run\PSScripts") `
    -credential $credential `
    -auth $auth `
    -artifactUrl $artifactUrl `
    -licenseFile $licenseFile `
    -memoryLimit 8G `
    -updateHosts `



if (Test-Path $appFileApp1)
{
    Publish-BcContainerApp  -containerName $containerName `
                            -appFile $appFileApp1 `
                            -skipVerification `
                            -sync `
                            -install
}


if (Test-Path $appFileApp2)
{
    Publish-BcContainerApp  -containerName $containerName `
                            -appFile $appFileApp2 `
                            -skipVerification `
                            -sync `
                            -install
}


Copy-Item -Path "D:\AL\ctm.al.project.template\PSScripts\DeleteAllUserDataFromDB.sql" -Destination "C:\ProgramData\BcContainerHelper\extensions\$containerName\my\DeleteAllUserDataFromDB.sql"

Invoke-ScriptInBcContainer -containerName $containerName -scriptblock {
    Invoke-Sqlcmd -Database "CRONUS" -InputFile "C:\run\my\DeleteAllUserDataFromDB.sql"
    }

Backup-BcContainerDatabases -containerName $containerName -bakFolder "C:\ProgramData\BcContainerHelper\extensions\$containerName\my"

Copy-FileFromBcContainer -containerName $containerName -containerPath "C:\run\my\database.bak" -localPath "D:\SQL\database.bak"


Remove-BcContainer -containerName $containerName
