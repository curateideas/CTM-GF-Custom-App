/* Script to delete all userdata NAV/BC Database */

USE [CRONUS]
GO

DELETE FROM [dbo].[User]
DELETE FROM [dbo].[User Personalization]
DELETE FROM [dbo].[Access Control]
DELETE FROM [dbo].[User Property]
DELETE FROM [dbo].[Page Data Personalization]
DELETE FROM [dbo].[User Default Style Sheet]
DELETE FROM [dbo].[User Metadata]
DELETE FROM [dbo].[User Personalization]
DELETE from [dbo].[Active Session]
DELETE from [dbo].[Session Event]
