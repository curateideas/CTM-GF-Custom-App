﻿Param(
    [Parameter(Mandatory=$false)]
    [string] $version = "bc19",
    [string] $containerName = "",
    [switch] $reUseContainer,
    [string] $sharedFolder = ""
)

$containerNameParam = $containerName
$baseFolder = (Get-Item (Join-Path $PSScriptRoot "..")).FullName
. (Join-Path $PSScriptRoot "Read-Settings.ps1") -environment 'Local' -version $version
. (Join-Path $PSScriptRoot "Install-BcContainerHelper.ps1") -bcContainerHelperVersion $bcContainerHelperVersion -genericImageName $genericImageName
if ($containerNameParam) { $containerName = $containerNameParam }

$licenseFile = "..\License\BC_Prog_CTM_4805307.flf"
$password = "P@ssw0rd"
$securePassword = ConvertTo-SecureString -String $password -AsPlainText -Force
$credential = New-Object pscredential 'admin', $securePassword

$allTestResults = "testresults*.xml"
$testResultsFile = Join-Path $baseFolder "TestResults.xml"
$testResultsFiles = Join-Path $baseFolder $allTestResults
if (Test-Path $testResultsFiles) {
    Remove-Item $testResultsFiles -Force
}

Run-AlPipeline `
    -pipelineName $pipelineName `
    -containerName $containerName `
    -artifact $artifact `
    -memoryLimit $memoryLimit `
    -baseFolder $baseFolder `
    -sharedFolder $sharedFolder `
    -licenseFile $licenseFile `
    -installApps $installApps `
    -installTestApps $installTestApps `
    -appFolders $appFolders `
    -testFolders $testFolders `
    -testResultsFile $testResultsFile `
    -testResultsFormat 'JUnit' `
    -installTestRunner:$installTestRunner `
    -installTestFramework:$installTestFramework `
    -installTestLibraries:$installTestLibraries `
    -installPerformanceToolkit:$installPerformanceToolkit `
    -credential $credential `
    -doNotRunTests `
    -useDevEndpoint `
    -updateLaunchJson "Local Dev Environment" `
    -keepContainer `    -reUseContainer:$reUseContainer
